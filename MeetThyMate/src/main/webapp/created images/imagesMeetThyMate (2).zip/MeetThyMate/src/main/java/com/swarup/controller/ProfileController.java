package com.swarup.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.swarup.dao.UserDAO;
import com.swarup.exception.AdException;
import com.swarup.pojo.User;

@Controller
public class ProfileController {
	@RequestMapping(value="/profile.htm")
	public String showProfile(HttpServletRequest request, HttpServletResponse response) throws AdException{
		String memberName="";
		int id=0;
		int lookupType = Integer.parseInt(request.getParameter("type"));
		if (lookupType == 1)
			id = Integer.parseInt(request.getParameter("data"));
		if (lookupType == 2)
		      memberName = request.getParameter("data");
		
		
		UserDAO userDAO=new UserDAO();
		User user=userDAO.get(memberName);
		
		
		request.getSession().setAttribute("user", user);
		return "profile";
	}
}
