package com.swarup.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.web.multipart.MultipartFile;

import com.swarup.exception.AdException;
import com.swarup.pojo.Address;
//import com.swarup.pojo.Address;
import com.swarup.pojo.User;

public class UserDAO extends DAO{
	public UserDAO() {
    }
	
	public User get(String username)
            throws AdException {
        try {
            begin();
            Query q = getSession().createQuery("from User where userName = :username");
            q.setString("username", username);
            User user = (User) q.uniqueResult();
            commit();
            return user;
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not get user " + username, e);
        }
    }
	
	public User create(String userName, String password, String firstName, String lastName, String gender, String email, String phone, String street, int aptNo, String city, String country, String state, int zip) throws AdException{
		try{
			begin();
			User user=new User();
			Address address=new Address();
			user.setFirstName(firstName);
			user.setGender(gender);
			user.setAddress(address);
			user.setUserName(userName);
			user.setUserPassword(password);
			user.setLastName(lastName);
			user.setEmail(email);
			user.setPhone(phone);
			address.setAptNo(aptNo);
			address.setCity(city);
			address.setCountry(country);
			address.setState(state);
			address.setStreet(street);
			address.setZip(zip);
//			photo.setPhotoName(profilePic);
			
			getSession().save(user);
			getSession().save(address);
			commit();
			return user;
		}
		catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create user " + username, e);
            throw new AdException("Exception while creating user: " + e.getMessage());
        }	
	}
		public void delete(User user) throws AdException {
	        try {
	            begin();
	            getSession().delete(user);
	            commit();
	        } catch (HibernateException e) {
	            rollback();
	            throw new AdException("Could not delete user " + user.getFirstName(), e);
	        }
	    }
		
		public User validateUser(String uname, String pwd) throws AdException{
			try {
	            begin();
	            Query q = getSession().createQuery("from User where userName = :username");
	            q.setString("username", uname);
	            User user = (User) q.uniqueResult();
	            if(user.getUserPassword().equals(pwd)){
	            	commit();
		            return user;
	            }
	     
	        } catch (HibernateException e) {
	            rollback();
	            throw new AdException("Could not get user " + uname, e);
	        }
			return null;
		}
	}
