package com.swarup.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.swarup.dao.UserDAO;
import com.swarup.exception.AdException;
//import com.swarup.pojo.Address;
import com.swarup.pojo.User;

@Controller
public class RegisterNewUser {
	
	@RequestMapping("/register.htm")
	public String initializeRegistrationForm(@ModelAttribute("user") User user, BindingResult result){
		
		return "register01";
	}
	

	
	@RequestMapping("/register02.htm")
	public String formStep3(@ModelAttribute("user")User user, BindingResult result){
		try {
			System.out.print("test");
			UserDAO userDao = new UserDAO();
			System.out.print("test1");

			userDao.create(user.getUserName(), user.getUserPassword(), user.getFirstName(), user.getLastName(), user.getGender(), user.getEmail(), user.getPhone(), user.getAddress().getStreet(), user.getAddress().getAptNo(), user.getAddress().getCity(), user.getAddress().getState(), user.getAddress().getState(),user.getAddress().getZip());
			
			// DAO.close();
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
		
		return "userLoggedIn";
	}
	

		
}
