package com.swarup.pojo;

import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name="friendtable")
public class Friend {
	@Id 
	@GeneratedValue
	@Column(name="friendID", unique = true, nullable = false)
	private int friendID;
	
	@Column(name="friendName")
	private User friendName;
	

	
	
	
	
	
	public int getFriendID() {
		return friendID;
	}
	public void setFriendID(int friendID) {
		this.friendID = friendID;
	}
	public User getFriend() {
		return friendName;
	}
	public void setFriend(User friend) {
		this.friendName = friend;
	}	
}
