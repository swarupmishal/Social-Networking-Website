package com.swarup.pojo;

import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name="messagetable")
public class Message {
	
	@Id @GeneratedValue
	@Column(name="messageID", unique=true, nullable=false )
	private int messageID;
	
	@Column(name="fromUser")
	private User fromUser;
    
	@Column(name="userName")
	private User userName;
    
	@Column(name="msg")
	private String msg;
    
	@Column(name="messageDate")
	private Date messageDate;
	
	
	
	
	
	
	public int getMessageID() {
		return messageID;
	}
	public void setMessageID(int messageID) {
		this.messageID = messageID;
	}
	public User getFromUser() {
		return fromUser;
	}
	public void setFromUser(User fromUser) {
		this.fromUser = fromUser;
	}
	public User getUserName() {
		return userName;
	}
	public void setUserName(User userName) {
		this.userName = userName;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Date getMessageDate() {
		return messageDate;
	}
	public void setMessageDate(Date messageDate) {
		this.messageDate = messageDate;
	}
    
    
}
